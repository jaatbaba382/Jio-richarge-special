function showPlans() {
  const number = document.getElementById('mobileNumber').value;
  if (number.length === 10) {
    document.getElementById('plans').style.display = 'block';
  } else {
    alert('Please enter a valid 10 digit mobile number');
  }
}

function showQR() {
  document.getElementById('qrPopup').style.display = 'block';
}
